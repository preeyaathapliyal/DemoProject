<?php
class NoTestCaseClass
{
}
